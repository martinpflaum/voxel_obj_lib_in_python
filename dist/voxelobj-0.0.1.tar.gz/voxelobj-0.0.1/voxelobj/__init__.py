__author__ = 'Martin Pflaum'
__version__ = '0.0.1'

from .core import WorldGrid,write